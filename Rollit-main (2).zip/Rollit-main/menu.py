from fltk import *
from PIL import Image
from miniMax_lvl3 import *
from random_lvl1 import *
from semiRandom_lvl2 import *
from jeu import *
def step1():
    # Display the background image
    image(427, 240, 'menu/1.png', largeur=854, hauteur=480, ancrage='center', tag='im')
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        if tev == "Quitte":
            ferme_fenetre()
            break

        if tev == "ClicGauche":
            x, y = abscisse(ev), ordonnee(ev)

            if 361 <= x <= 490 and 267 <= y <= 325:
                print(x, y)  # jouer
                step2(step1)  # Pass step1 as the previous step

            if 361 <= x <= 493 and 358 <= y <= 415:
                print(x, y)  # s'entrainer
                step5(step1)  # Pass step1 as the previous step

        mise_a_jour()

def step2(previous_step):
    # Display the background image
    image(427, 240, 'menu/2.png', largeur=854, hauteur=480, ancrage='center', tag='im')
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        if tev == "Quitte":
            ferme_fenetre()
            break

        if tev == "ClicGauche":
            x, y = abscisse(ev), ordonnee(ev)
            print(x, y)  # s'entrainer
            if 327 <= x <= 527 and 276 <= y <= 333:
                print("nouvelle partie")
                step3(step2)  # Pass step2 as the previous step

            if 327 <= x <= 527 and 371 <= y <= 433:
                print("s'entrainer")
                step5(step2)  # Pass step2 as the previous step

            if 724 <= x <= 804 and 371 <= y <= 433:
                print('retour')
                previous_step(previous_step)  # Go back to the previous step

        mise_a_jour()

def step3(previous_step):
    # Display the background image
    image(427, 240, 'menu/3.png', largeur=854, hauteur=480, ancrage='center', tag='im')
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        if tev == "Quitte":
            ferme_fenetre()
            break

        if tev == "ClicGauche":
            x, y = abscisse(ev), ordonnee(ev)
            print(x, y)  # s'entrainer
            if 48 <= x <= 251 and 276 <= y <= 334:
                print('2 joueur')
                step4(step2,2)

            if 326 <= x <= 526 and 276 <= y <= 334:
                print('3 joueur')
                step4(step2, 3)

            if 602 <= x <= 804 and 276 <= y <= 334:
                print('4 joueur')
                step4(step2, 4)

            if 724 <= x <= 804 and 371 <= y <= 433:
                print('retour')
                previous_step(previous_step)  # Go back to the previous step

        mise_a_jour()

def step4(previous_step,nb):
    # Display the background image
    image(427, 240, 'menu/4.png', largeur=854, hauteur=480, ancrage='center', tag='im')
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        if tev == "Quitte":
            ferme_fenetre()
            break

        if tev == "ClicGauche":
            x, y = abscisse(ev), ordonnee(ev)
            print(x, y)  # s'entrainer

            if 69 <= x <= 183 and 310 <= y <= 348:
                print("4x4")
                ferme_fenetre()
                lancer_jeu(nb,4)

            if 377 <= x <= 491 and 309 <= y <= 348:
                print('6x6')
                ferme_fenetre()
                lancer_jeu(nb,6)

            if 687 <= x <= 802 and 309 <= y <= 347:
                print('9x9')
                ferme_fenetre()
                lancer_jeu(nb,9)

            if 724 <= x <= 804 and 371 <= y <= 433:
                print('retour')
                previous_step(previous_step)  # Go back to the previous step

        mise_a_jour()

def step5(previous_step):
    # Display the background image
    image(427, 240, 'menu/5.png', largeur=854, hauteur=480, ancrage='center', tag='im')
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        if tev == "Quitte":
            ferme_fenetre()
            break

        if tev == "ClicGauche":
            x, y = abscisse(ev), ordonnee(ev)
            print(x, y)  # s'entrainer
            if 48 <= x <= 251 and 276 <= y <= 334:
                print('niveau 1')
                ferme_fenetre()
                lvl1()

            if 326 <= x <= 526 and 276 <= y <= 334:
                print('niveau2')
                ferme_fenetre()
                lvl2()

            if 602 <= x <= 804 and 276 <= y <= 334:
                print('niveau max')
                ferme_fenetre()
                lvl3()

            if 724 <= x <= 804 and 371 <= y <= 433:
                print('retour')
                previous_step(previous_step)  # Go back to the previous step

        mise_a_jour()
cree_fenetre(854, 480)
step1()