from fltk import *
from PIL import Image

# Create a window
cree_fenetre(854, 480)

# Display the background image
image(427, 240, 'menu/1.png', largeur=854, hauteur=480, ancrage='center', tag='im')
fenetre_cree = True
while True:
    ev = donne_ev()
    tev = type_ev(ev)
    if tev == "Quitte":
        ferme_fenetre()
        fenetre_cree = False
        break

    if tev == "ClicGauche":
        x, y = abscisse(ev), ordonnee(ev)

        if 361 <= x <= 490 and 267 <= y <= 325:
            print(x, y)  # jouer
        if 361 <= x <= 493 and 358 <= y <= 415:
            print(x, y)  # s'entrainer



    mise_a_jour()




