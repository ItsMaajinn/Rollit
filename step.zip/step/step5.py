from fltk import *
from PIL import Image

# Create a window
cree_fenetre(854, 480)

# Display the background image
image(427, 240, 'menu/5.png', largeur=854, hauteur=480, ancrage='center', tag='im')
fenetre_cree = True
while True:
    ev = donne_ev()
    tev = type_ev(ev)
    if tev == "Quitte":
        ferme_fenetre()
        fenetre_cree = False
        break

    if tev == "ClicGauche":
        x, y = abscisse(ev), ordonnee(ev)
        print(x, y)  # s'entrainer
        if 48 <= x <= 251 and 276 <= y <= 334:
           print('niveau 1')

        if 326 <= x <= 526 and 276 <= y <= 334:
            print('niveau2')

        if 602 <= x <= 804 and 276 <= y <= 334:
            print('niveau max')

        if 724 <= x <= 804 and 371 <= y <= 433:
            print('retour')






        #if 361 <= x <= 493 and 358 <= y <= 415:




    mise_a_jour()




