from fltk import *
from PIL import Image

# Create a window
cree_fenetre(854, 480)

# Display the background image
image(427, 240, 'menu/2.png', largeur=854, hauteur=480, ancrage='center', tag='im')
fenetre_cree = True
while True:
    ev = donne_ev()
    tev = type_ev(ev)
    if tev == "Quitte":
        ferme_fenetre()
        fenetre_cree = False
        break

    if tev == "ClicGauche":
        x, y = abscisse(ev), ordonnee(ev)
        print(x, y)  # s'entrainer
        if 327 <= x <= 527 and 276 <= y <= 333:
            print("nouvelle partie")

        if 327 <= x <= 527 and 371 <= y <= 433:
            print("s'entrainer")

        if 724 <= x <= 804 and 371 <= y <= 433:
            print('retour')


    mise_a_jour()




