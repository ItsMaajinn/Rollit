from fltk import *
from PIL import Image

# Create a window
cree_fenetre(854, 480)

# Display the background image
image(427, 240, 'menu/4.png', largeur=854, hauteur=480, ancrage='center', tag='im')
fenetre_cree = True
while True:
    ev = donne_ev()
    tev = type_ev(ev)
    if tev == "Quitte":
        ferme_fenetre()
        fenetre_cree = False
        break

    if tev == "ClicGauche":
        x, y = abscisse(ev), ordonnee(ev)
        print(x, y)  # s'entrainer

        if 69 <= x <= 183 and 310 <= y <= 348:
            print("4x4")

        if 377 <= x <= 491 and 309 <= y <= 348:
            print('6x6')

        if 687 <= x <= 802 and 309 <= y <= 347:
            print('9x9')

        if 724 <= x <= 804 and 371 <= y <= 433:
            print('retour')



    mise_a_jour()




