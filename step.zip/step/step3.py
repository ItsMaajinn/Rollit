from fltk import *
from PIL import Image

# Create a window
cree_fenetre(854, 480)

# Display the background image
image(427, 240, 'menu/3.png', largeur=854, hauteur=480, ancrage='center', tag='im')
fenetre_cree = True
while True:
    ev = donne_ev()
    tev = type_ev(ev)
    if tev == "Quitte":
        ferme_fenetre()
        fenetre_cree = False
        break

    if tev == "ClicGauche":
        x, y = abscisse(ev), ordonnee(ev)
        print(x, y)  # s'entrainer
        if 48 <= x <= 251 and 276 <= y <= 334:
            print('2 joueur')

        if 326 <= x <= 526 and 276 <= y <= 334:
            print('3 joueur')

        if 602 <= x <= 804 and 276 <= y <= 334:
            print('4 joueur')

        if 724 <= x <= 804 and 371 <= y <= 433:
            print('retour')

    mise_a_jour()




